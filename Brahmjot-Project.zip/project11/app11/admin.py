from django.contrib import admin

from.models import SchoolReg,School
class schooldata(admin.ModelAdmin):
    list_display = [
        "fName",
        "sName",
        "userName",
        "phone",
        "email",
        "password",
        "re_password",
    ]

admin.site.register(SchoolReg, schooldata)

class School_data(admin.ModelAdmin):
    list_display=[
        "userName",
        "password"
    ]
admin.site.register(School,School_data)